public class Main {

    public static void main(String[] args) {


        HashTable<String, Integer> hashTable = new HashTable<>();

        hashTable.add("ONe", 1);
        hashTable.add("Two", 2);
    }
}
